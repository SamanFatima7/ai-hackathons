# **🐍 Python Buddy: Your Personal AI Code Coach**

**Submission for the GPT-5 Hackathon: "Build the Future"**

**Python Buddy** is an intelligent, AI-powered learning platform designed to solve a fundamental problem in programming education: it teaches you how to *think* like a programmer. It moves beyond passive tutorials by creating a hands-on environment where users learn a concept, apply it immediately, and receive AI-driven feedback that guides them without ever giving away the answer.

## **Hackathon Submission Details**

This project was built to meet the core criteria of the GPT-5 Hackathon: creating an innovative, production-ready AI application that solves a real-world problem.

### **1\. Clear User Value — A Solution People Genuinely Need**

The online education (EdTech) market is booming, yet most platforms still follow a passive, one-size-fits-all model. Python Buddy solves three major pain points for aspiring developers:

* **The Tutorial Trap:** It replaces passive video watching with active, hands-on coding to build real skills.  
* **The Frustration Barrier:** When a user gets stuck, our AI acts as a Socratic tutor, asking guiding questions instead of giving the answer. This teaches the critical skill of debugging.  
* **The Quality Gap:** Our AI Code Coach refactors a user's working code to a professional standard, teaching the difference between code that *works* and code that is *good*.

### **2\. Scalability — Growth Potential**

The architecture is designed to scale effortlessly:

* **Content:** The curriculum and practice problems are stored in a simple, structured format, allowing us to easily add more advanced modules (Object-Oriented Programming, APIs, Data Structures) without changing the core application.  
* **User Base:** As a web-based application, it can serve a global audience of learners simultaneously.

### **3\. Market Potential — Viable for Real-World Launch**

Python Buddy targets the massive and underserved market of self-taught developers, students, and professionals looking to upskill. It has the potential to be a premium educational tool for:

* Individual learners (subscription model).  
* Educational institutions (licensing model).  
* Corporate training programs.

## **Our Solution: An AI-Powered Learning Loop**

Python Buddy is built on a powerful three-stage learning loop that leverages AI at every step to create a unique educational experience.

### **1\. Adaptive AI Teaching**

In our **"Learn" Tab**, if a user answers a question incorrectly, our AI acts as an **Adaptive Teacher**, re-explaining the concept in a completely new way, using a different analogy or example each time until the user understands.

### **2\. Socratic Hint System**

In the **"Practice Arena,"** the AI becomes a Socratic tutor. It analyzes a user's specific mistake and provides a **guiding question** that forces them to find the flaw in their own logic.

### **3\. AI Code Coach (Our "Wow" Feature)**

Once a user solves a problem correctly, the **AI Code Coach** reviews their working code. It then **refactors it to a professional standard** and provides a clear, line-by-line explanation of the improvements.

## **How We Built It (Tech Stack)**

* **Frontend:** **Gradio** for a fast, interactive user interface.  
* **Backend:** **Python** for all application logic.  
* **Core Technology (Required):** We use the **GPT-5 API** as the "brain" of our application. All three of our core AI features are powered by carefully engineered system prompts that instruct the model to act in a specific pedagogical role.

## **Future Vision: A Continuous Learning Journey**

This project is built to scale. Our vision for the future includes:

* **Spiral Learning Path:** As we add more advanced modules, the Practice Arena will be updated with more complex problems that **require users to combine new concepts with the fundamentals they've already mastered.**  
* **The Dynamic Tutor:** Our ultimate goal is an AI that can generate a complete, personalized curriculum on any topic a user wants to learn, creating an infinite and ever-evolving learning path.

## **How to Run**

1. **Clone the repository:**  
   git clone \<your-repo-url\>  
   cd \<your-repo-folder\>

2. **Install dependencies:**  
   pip install \-r requirements.txt

3. **Set your API Key Secret:** In your hosting environment (like Hugging Face Spaces), set a secret named AIML\_API\_KEY with your API key as the value.  
4. **Run the application:**  
   python app.py  
